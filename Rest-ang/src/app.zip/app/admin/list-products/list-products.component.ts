
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { ProductService } from 'src/app/product/service/product.service';



@Component({
  selector: 'app-list-products',
  templateUrl: './list-products.component.html',
  styleUrls: ['./list-products.component.scss']
})
export class ListProductsComponent  implements OnInit,OnChanges{
  
  @Input() searchstring='';
  @Output() editItem=new EventEmitter<any>();


  displayedColumns: string[] = ['name','description','price','actions'];
  dataSource:any[]=[]
  mainSource:any[]=[]
  loaded=false
  page='loading'

  constructor(private productService:ProductService){
    this.productService.productNotifier.subscribe(()=>{
      this.getFoodItems();
    })
  }

  ngOnInit(){
    this.getFoodItems()
  }
  ngOnChanges(changes: SimpleChanges){
    this.filterProducts ()
  }

  filterProducts(){
    console.log(this.searchstring);
    
    this.dataSource=[]
    this.mainSource.forEach((product:any)=>{
      if(product.name.includes(this.searchstring)){
        this.dataSource.push(product)
      }
    })
  }
  getFoodItems(){
   this.page='loading'
   this.loaded=true;
    this.productService.getfooditem()
    .subscribe((foodItems:any)=>{
      this.dataSource=foodItems
      console.log('......',foodItems);
      setTimeout(()=>{
        this.page='Complete'
      },0)
      this.dataSource=foodItems
      this.mainSource=this.dataSource
    });
  }
  
  onDelete(id:any){
    this.productService.deleteproduct(id)
    this.productService.onDelete.subscribe(()=>{
      this.getFoodItems()
    })
  }

  onEdit(id:any){
    console.log("tems",id);
    this.editItem.emit(id)

  }

}
