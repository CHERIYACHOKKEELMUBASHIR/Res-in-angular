import { Injectable } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { fooditems } from '../data/food-items';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products=fooditems;
  productNotifier=new Subject<void>()
  onDelete=new Subject<void>()
  productnotifier: any;

  

  constructor() { }

  getfooditem():Observable<any>{
    return of(this.products)
  }
  addproduct(name:any,price:any,description:any){
    const newProduct=Object.assign({},{
      "name": name,
      "description":description,
      "id": 2,
      "price":price,
      "iconName":"biriyani",
      "rating": 3,
      "imgToUrl":"https://c.ndtvimg.com/2022-09/1jsu8038_noodles_625x300_28_September_22.jpg?im=FaceCrop,algorithm=dnn,width=1200,height=886"


    })
    this.products.push(newProduct)
    this.productNotifier.next()    
  }
  deleteproduct(id:any){
    this.products.splice(this.products.findIndex(a=>a.id ===id),1)
    console.log(this.products);
    this.onDelete.next()
    
  }
  editproduct(id:any){
    this.products.splice(this.products.findIndex(a=>a.id ===id),1)
    console.log(this.products);
    this.onDelete.next()
    
  }
  updateProduct(product: any){
    this.products.forEach((item: any) => {
      if (product.id === item.id) {
        item.name = product.name;
        item.price = product.price;
        item.description = product.description;
      }
    });
    this.productnotifier.next();
  }
}


